# LastFMParser is courtesy of someone else - not sure who!

from xml.dom.minidom import parse, Element, Text

class LastFMParser(object):
    def get_value(self, node):
        if isinstance(node, Element):
            node.normalize()
            if len(node.childNodes) == 1:
                return node.firstChild.nodeValue
            else:
                return None
        else:
            return node.nodeValue

    def get_int(self, node):
        try:
            return int(self.get_value(node))
        except (ValueError, TypeError):
            return None

    def get_attributes_dict(self, element, attr_map):
        if not element.hasAttributes():
            return {}
        D = {}
        for attr, convert_func in attr_map.iteritems():
            if element.hasAttribute(attr):
                if callable(convert_func):
                    D[attr] = convert_func(element.getAttributeNode(attr))
                else:
                    D[attr] = element.getAttributeNode(attr)
        return D

    def get_elements_dict(self, node, element_map):
        element_names = element_map.keys()
        D = {}
        for child in node.childNodes:
            if isinstance(child, Element) and child.tagName in element_names:
                convert_func = element_map[child.tagName]
                if callable(convert_func):
                    D[child.tagName] = convert_func(child)
                else:
                    D[child.tagName] = child
        return D

    def get_elements(self, node, name, convert_func):
        elements = []
        for child in node.childNodes:
            if isinstance(child, Element) and child.tagName == name:
                element = convert_func(child)
                if element is not None:
                    elements.append(element)
        return elements

    def parse_document(self, document):
        return document

    def parse(self, file_or_filename):
        document = parse(file_or_filename)
        return self.parse_document(document)


class WeeklyChartListParser(LastFMParser):
    def get_chart(self, element):
        attr_map = {
            "from": self.get_int,
            "to": self.get_int,
        }
        return self.get_attributes_dict(element, attr_map)

    def parse_document(self, document):
        root = document.documentElement
        charts = self.get_elements(root, "chart", self.get_chart)
        return charts


class PreviousWeeklyTrackChartParser(LastFMParser):
    def get_artist(self, element):
        artist = {}
        if element.hasAttribute("mbid"):
            artist["mbid"] = self.get_value(element.getAttributeNode("mbid"))
        artist["name"] = self.get_value(element)
        return artist

    def get_track(self, element):
        element_map = {
            "artist": self.get_artist,
            "name": self.get_value,
            "mbid": self.get_value,
            "chartposition": self.get_int,
            "playcount": self.get_int,
            "url": self.get_value,
        }
        return self.get_elements_dict(element, element_map)

    def parse_document(self, document):
        root = document.documentElement
        tracks = self.get_elements(root, "track", self.get_track)
        return tracks

class TopTagParser(LastFMParser):
    def get_tag(self, element):
        element_map = {
            "name": self.get_value,
            "count": self.get_int,
        }
        return self.get_elements_dict(element, element_map)

    def parse_document(self, document):
        root = document.documentElement
        tags = self.get_elements(root, "tag", self.get_tag)
        return tags

class RecentTrackParser(LastFMParser):
    def get_track(self, element):
        element_map = {
            "name": self.get_value,
            "artist": self.get_value,
        }
        return self.get_elements_dict(element, element_map)

    def parse_document(self, document):
        root = document.documentElement
        tracks = self.get_elements(root, "track", self.get_track)
        return tracks

if __name__ == '__main__':
    p = TopTagParser()
    print p.parse("/home/boris/toptags.xml")
