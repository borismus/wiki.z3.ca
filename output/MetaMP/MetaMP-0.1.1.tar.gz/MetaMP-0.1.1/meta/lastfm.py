import urllib, urllib2
import time
from logging import error, warning

import parser
import config

TOP_TAG_TITLE = "http://ws.audioscrobbler.com/1.0/track/%(artist)s/%(title)s/toptags.xml"
TOP_TAG_ARTIST = "http://ws.audioscrobbler.com/1.0/artist/%(artist)s/toptags.xml"
WEEKLY_CHART_LIST = "http://ws.audioscrobbler.com/1.0/user/%(user)s/weeklychartlist.xml"
WEEKLY_TRACK_CHART = "http://ws.audioscrobbler.com/1.0/user/%(user)s/weeklytrackchart.xml?from=%(from)i&to=%(to)i"
RECENT_TRACK_LIST = "http://ws.audioscrobbler.com/1.0/user/%(user)s/recenttracks.xml"

def tag_data(artist, title=None):
    # first try tagging title
    tags = title_tag_data(artist, title)
    if not tags:
	# if no tag, data, go to artist
	tags = artist_tag_data(artist)
    if not tags:
	# if no tag by this point, give a warning
	warning("Unable to get tag data for track '%s - %s'" % (artist,
	    title))
	return ""
    return tags


def title_tag_data(artist, title):
    if not title:
	error("No title specified")
	return None
    if not artist:
	error("No artist specified")
	return None
    # try to get title data first
    url = TOP_TAG_TITLE % {
	    'title': urllib.quote(title), 
	    'artist': urllib.quote(artist)}
    try:
	f = urllib2.urlopen(url)
    except:
	error("Unable to get tag data from %s" % url) 
	return None
    p = parser.TopTagParser()
    tags = p.parse(f)
    return ",".join([t['name'] for t in tags][:config.getint("max_tags")])

def artist_tag_data(artist):
    if not artist:
	error("No artist specified")
	return None
    # try to get title data first
    url = TOP_TAG_ARTIST % {
	    'artist': urllib.quote(artist)}
    try:
	f = urllib2.urlopen(url)
    except:
	error("Unable to get tag data from %s" % url) 
	return None
    p = parser.TopTagParser()
    tags = p.parse(f)
    return ",".join([t['name'] for t in tags][:config.getint("max_tags")])

def recent_tracks(user):
    url = RECENT_TRACK_LIST % {'user': urllib.quote(user)}
    f = urllib2.urlopen(url)
    p = parser.RecentTrackParser()
    tracks = p.parse(f)
    return tracks


if __name__ == "__main__":
    print recent_tracks("miraage")
