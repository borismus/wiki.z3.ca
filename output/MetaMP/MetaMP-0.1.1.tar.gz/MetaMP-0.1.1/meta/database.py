from pysqlite2 import dbapi2 as sqlite
import os
from logging import error, warning

# TODO: ugly constant
UNRATED = -1

class Connection:

    def __init__(self, path):
	self.con = sqlite.connect(path) 
	self.cur = self.con.cursor()
	# verify that the database exists.
	self.create_db()

    def close(self):
	self.commit()
	self.con.close()

    def commit(self):
	self.con.commit()

    def create_db(self):
	try:
	    self.cur.executescript("""
	    CREATE TABLE meta(
		path text PRIMARY KEY,
		rating integer,
		tags text
	    );
	    """)
	except sqlite.OperationalError:
	    warning("Database meta already exists")

    def create_entry(self, path, rating=UNRATED, tags=""):
	try: 
	    self.cur.execute("insert into meta(path, rating, tags) values (?, ?, ?)",
		    (path, rating, tags))
	except sqlite.IntegrityError:
	    warning('Row "%s" already exists' %path)

    def set_rating(self, path, rating): 
	self.cur.execute("update meta set rating = ? where path = ?", (rating, path))

    def get_rating(self, path):
	self.cur.execute("select rating from meta where path = ?", (path,))
	return self.cur.fetchone()

    def set_tags(self, path, tags):
	self.cur.execute("update meta set tags = ? where path = ?", (tags, path))

    def get_tags(self, path):
	self.cur.execute("select tags from meta where path = ?", (path,))
	#result = self.cur.fetchone()
	#return result
	return self.cur.fetchone()

    def get_songs_with_tag(self, tag):
	self.cur.execute("select path from meta where tags like ?", ("%"+tag+"%",))
	return [path[0] for path in self.cur.fetchall()]

if __name__ == '__main__':
    import config
    c = Connection(config.get('db'))
    c.create_entry("gypsy kings")
    c.set_rating("gypsy kings", 5)
    print c.get_songs_with_tag("chill")
    c.close()
