"""
 MetaMP package

 Copyright (C) 2007 Boris Smus <boris@z3.ca>
 Licence: GPL [see http://www.gnu.org/copyleft/gpl.html]
"""
