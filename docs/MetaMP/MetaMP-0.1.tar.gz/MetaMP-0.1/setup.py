from distutils.core import setup
setup(name='MetaMP',
      version='0.1',
      packages = ["meta"],
      scripts = ["metamp"],
      url = "http://z3.ca/MetaMP",
      author = "Boris Smus",
      description = "MetaMP is a metadata manager for mpd",
      author_email = "boris@z3.ca",
      )
