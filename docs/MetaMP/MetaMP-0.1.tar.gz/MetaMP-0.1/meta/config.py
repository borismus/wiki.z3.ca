from logging import error, warning
import os
import ConfigParser

CONF_PATH = ["/etc/metamp.conf", "~/.metamp"]

def init_parser():

    parser = ConfigParser.ConfigParser(
	    {
		'max_tags': '5',
		'auto_play': 'No',
		'log_level': "ERROR"
	    })

    for path in CONF_PATH:
	path = os.path.expanduser(path)
	if os.path.exists(path): 
	    parser.read(path)
	    return parser

    raise ConfigParser.Error, "No configuration found in " + \
	    " or ".join(CONF_PATH)

def get(opt):
    return init_parser().get('conf', opt)

def getboolean(opt):
    return init_parser().getboolean('conf', opt)

def getint(opt):
    return init_parser().getint('conf', opt)

if __name__ == '__main__':
    print get('db')
